package cadastrojogos;

public class App_jogo {

	public static void main(String[] args) {
		new FrmJogo();

	}

}
