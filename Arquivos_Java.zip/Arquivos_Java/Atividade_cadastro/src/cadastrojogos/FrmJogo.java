package cadastrojogos;
import java.awt.*;
import javax.swing.*;

public class FrmJogo extends JFrame {
	


public FrmJogo() {
	

}
}

