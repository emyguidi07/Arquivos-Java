package excalculadora;

import excalculadora.Calculadora;

public class App_calculo{
	public static void main(String[] args) {
		new Calculadora();
	}
}