import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Menu extends JFrame{
 
    public Menu(){
   
       super("Exemplo JTabbedPane");

       JMenu arq = new JMenu("Arquivo");
       JMenu cad = new JMenu("Cadastrar"); 
       
       JMenuItem sair = new JMenuItem("Sair"); 
       JMenuItem alu = new JMenuItem("Aluno");
              
       arq.add(sair);
       cad.add(alu);
       
       JMenuBar bar = new JMenuBar();
       setJMenuBar(bar);
       bar.add(arq);
       bar.add(cad); 
             
       sair.addActionListener(
         new ActionListener(){
             public void actionPerformed(ActionEvent event){
               System.exit(0);
             }
         }
       );
       
       alu.addActionListener(
         new ActionListener(){
             public void actionPerformed(ActionEvent event){
                ObjetoJTabbedPane aluno = new ObjetoJTabbedPane();                
                aluno.setVisible(true);                
             }
         }
       );  

    } 
}