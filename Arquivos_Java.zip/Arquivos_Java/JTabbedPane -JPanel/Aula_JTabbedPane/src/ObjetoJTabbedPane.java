import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ObjetoJTabbedPane extends JDialog{

   
   private JLabel lblcod,lblnome,lblfone;
   private JTextField txtcod,txtnome,txtfone;
   private JButton btExibir;
  
   public ObjetoJTabbedPane(){     
	     this.setTitle("Cadastro de Alunos");
	     this.setModal(true);
	     this.setSize(500,470);  
	     this.setResizable(false);  
	   
	     Container janelacalc = this.getContentPane();
	     setLocationRelativeTo(janelacalc);
	     janelacalc.setLayout(null);  
	     
		 //cria o JTabbedPane
		 JTabbedPane tabbedpane = new JTabbedPane();
	  
		 //Primeira guia
	  
		 //tamanho e posicionamento do JTabbedPane
		 tabbedpane.setBounds(0,0,500,470);     
	  
		  JPanel painel1 = new JPanel();
		  painel1.setLayout(null);
		  
		  lblcod = new JLabel("C�digo:");
		  lblcod.setBounds(10,15,50,20);     
		  painel1.add(lblcod);   
		     
		  txtcod = new JTextField();
		  txtcod.setBounds(55, 15, 150, 20);
		  painel1.add(txtcod);
		  
		  btExibir = new JButton("Exibir Mensagem");
		  btExibir.setBounds(15,350,150,20);
		  painel1.add(btExibir);
		
		  EventoBotao evb = new EventoBotao();
		  btExibir.addActionListener(evb);
		  
		  tabbedpane.addTab("Aba 1", null,painel1,"Primeiro Painel");
		  
		  //fim primeira guia do JTabbedPane
		  
		  //segunda guia  
		  JPanel painel2 = new JPanel();
		  painel2.setLayout(null);
		  painel2.setBackground(Color.WHITE);
		  
		  lblnome = new JLabel("Nome:");
		  lblnome.setBounds(10, 15, 50, 20);
		  painel2.add(lblnome);
		  
		  txtnome = new JTextField();
		  txtnome.setBounds(55, 15, 150, 20);
		  painel2.add(txtnome);
		  
		  tabbedpane.addTab("Aba 2", null,painel2,"Segundo Painel");  
		     
		  //final segunda guia do JTabbedPane   
		  
		  //terceira guia
		  JPanel painel3 = new JPanel(); 
		  painel3.setLayout(null);
		  
		  lblfone = new JLabel("Telefone:");
		  lblfone.setBounds(10, 15, 150, 20);
		  painel3.add(lblfone);
		  
		  txtfone = new JTextField();
		  txtfone.setBounds(155, 15, 150, 20);
		  painel3.add(txtfone);
		  
		  tabbedpane.addTab("Aba 3", null,painel3,"Terceiro Painel");	  
		     
		  //adicional o JTabbedPane ao formul�rio
		  janelacalc.add(tabbedpane);    
	
	  }
	
	   //classe para inserir evento no botao btnins
	   private class EventoBotao implements ActionListener{
	       public void actionPerformed(ActionEvent event){
	    	   JOptionPane.showMessageDialog(null,"Testando um bot�o");	         
	        }   
	   }	   
}