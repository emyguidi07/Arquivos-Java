package poo_interface;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Formulario extends JFrame{
	JLabel nome_form;
	JLabel Nome ;
	JLabel Desc;
	JLabel Valor;
	JTextField Nome1;
	JTextField Desc1;
	JTextField Valor1;
	JButton cadastro;
		
	public Formulario() {
		this.setSize(500,350);
		this.setTitle("Cadastro de produto");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.darkGray);
		this.setResizable(true);
		
		
		Container c = getContentPane();
		c.setLayout(null);
		
		nome_form = new JLabel();
		nome_form.setText("Cadastro");
		nome_form.setBounds(50, 30, 100, 30);
		nome_form.setForeground(Color.white);
		c.add(nome_form);
		
		Nome = new JLabel();
		Nome.setText("Produto:");
		Nome.setBounds(50, 75, 100, 30);
		Nome.setForeground(Color.white);
		c.add(Nome);
		
		Nome1 = new JTextField();
		Nome1.setBounds(110, 75, 200, 30);
		c.add(Nome1);
		
		Desc = new JLabel();
		Desc.setText("Descri��o:");
		Desc.setBounds(50, 120, 100, 30);
		Desc.setForeground(Color.white);
		c.add(Desc);
		
		Desc1 = new JTextField();
		Desc1.setBounds(110, 120, 200, 30);
		c.add(Desc1);
		
		Valor = new JLabel();
		Valor.setText("Valor(R$):");
		Valor.setBounds(50, 165, 100, 30);
		Valor.setForeground(Color.white);
		c.add(Valor);
		
		Valor1 = new JTextField();
		Valor1.setBounds(110, 165, 200, 30);
		c.add(Valor1);
		
		cadastro = new JButton();
		cadastro.setBounds(50,230, 180, 30);
		cadastro.setBackground(Color.BLUE);
		cadastro.setForeground(Color.white);
		cadastro.setText("Cadastrar");
		c.add(cadastro);
		
		cadastro.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Produto p1 = new Produto();
				p1.setNome(Nome1.getText()); 
				p1.setDescricao(Desc1.getText());
				p1.setValor(Float.parseFloat(Valor1.getText()));
				JOptionPane.showMessageDialog(null, "Cadastro do produto:  \n" + " Produto: " + p1.getNome() + "\n Descri��o:"+ p1.getDescricao() + "\n Valor(R$):" + p1.getValor());
			}
		});
		this.setVisible(true); 
}
}
