package poo_interface;

public class app_produto {

	public static void main(String[] args) {
		new Formulario ();

	}

}
