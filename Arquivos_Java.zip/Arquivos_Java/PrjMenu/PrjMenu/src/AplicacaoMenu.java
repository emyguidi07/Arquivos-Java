
public class AplicacaoMenu {

	public static void main(String[] args) {
		FrmMenu frm = new FrmMenu();		
		frm.setSize(800,600);
	    frm.setVisible(true);
	    frm.setDefaultCloseOperation(frm.EXIT_ON_CLOSE);
	    frm.setLocationRelativeTo(null);
	}
}