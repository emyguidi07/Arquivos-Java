import javax.swing.JDialog;
import javax.swing.JLabel;

public class FrmCliente extends JDialog{
	JLabel lbNome;
	
	public FrmCliente() {
		setTitle("Cliente");
	    setModal(true);
	    setSize(400,300);  
	    setResizable(false);
	    setLocationRelativeTo(null);
	    
	    lbNome = new JLabel("Nome:");     
	    lbNome.setBounds(45,40,50,20);
	    add(lbNome);	     
	}

}
