import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.*;

public class FrmMenu extends JFrame {
	
	public FrmMenu(){
		   
	       super("Formul�rio com Menu");

	       JMenu arq = new JMenu("Arquivo");
	       JMenu cad = new JMenu("Cadastrar"); 
	       JMenu prod = new JMenu("Produto"); 
	       
	       JMenuItem sair = new JMenuItem("Sair"); 
	       JMenuItem cli = new JMenuItem("Cliente");
	       JMenuItem pd = new JMenuItem("Produto");
	              
	       arq.add(sair);
	       cad.add(cli);
	       prod.add(pd);
	       
	       JMenuBar bar = new JMenuBar();
	       setJMenuBar(bar);
	       bar.add(arq);
	       bar.add(cad); 
	       bar.add(prod);
	             
	       sair.addActionListener(
	         new ActionListener(){
	             public void actionPerformed(ActionEvent event){
	            	 int resposta = JOptionPane.showConfirmDialog(null,"Deseja sair?");
	            	 if(resposta == JOptionPane.YES_OPTION) {
	            		 System.exit(0);
	            	 }
	            	 else{
	            		 return;
	            		 }
	             }
	         }
	       );
	       
	       cli.addActionListener(
	         new ActionListener(){
	             public void actionPerformed(ActionEvent event){
	                FrmCliente frmCli = new FrmCliente();                
	                frmCli.setVisible(true);	               
	             }
	         }
	       );
	       
	       pd.addActionListener(
	  	         new ActionListener(){
	  	             public void actionPerformed(ActionEvent event){
	  	                FrmProduto frmPro = new FrmProduto();                
	  	                frmPro.setVisible(true);	               
	  	             }
	  	         }
	  	       );
	   } 
}
