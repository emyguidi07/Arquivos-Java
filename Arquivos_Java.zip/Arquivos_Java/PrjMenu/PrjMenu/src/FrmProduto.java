
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class FrmProduto extends JDialog{
	JLabel Nome ;
	JLabel Qtd;
	JLabel Valor;
	JTextField Nome1;
	JTextField Qtd1;
	JTextField Valor1;
	JButton cadastro;
	
public FrmProduto(){
	setTitle("Produto");
    setSize(500,350);  
    setResizable(false);
    setLocationRelativeTo(null);
    
    Container c = getContentPane();
	c.setLayout(null);
    
    Nome = new JLabel("Nome:");
	Nome.setBounds(45,40,50,20);
	add(Nome);
	
	Nome1 = new JTextField();
	Nome1.setBounds(115, 40, 150, 20);
	c.add(Nome1);
	
	Qtd = new JLabel("Qtd:");
	Qtd.setBounds(45, 70, 50, 20);
	add(Qtd);
	
	Qtd1 = new JTextField();
	Qtd1.setBounds(115, 70, 150, 20);
	c.add(Qtd1);
	
	Valor= new JLabel("Valor:");
	Valor.setBounds(45, 100, 50, 20);
	add(Valor);
	
	Valor1 = new JTextField();
	Valor1.setBounds(115, 100, 150, 20);
	c.add(Valor1);
	
	cadastro = new JButton();
	cadastro.setBounds(45,150,200, 30);
	cadastro.setBackground(Color.BLUE);
	cadastro.setForeground(Color.white);
	cadastro.setText("Exibir produto");
	c.add(cadastro);
	
	cadastro.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			String Nome = Nome1.getText();
			int Qtd = Integer.parseInt(Qtd1.getText());
			double valor = Double.parseDouble(Valor1.getText());
			JOptionPane.showMessageDialog(null, "Cadastro do produto:  \n" + " Produto: " + Nome + "\n Descri��o:"+ Qtd + "\n Valor(R$):" + valor);
		}
	});

	
}
}
