package br.com.etec.Default;
import br.com.etec.model.vo.*;
import br.com.etec.view.*;
import java.sql.SQLException;

import br.com.etec.controller.Clientecontrol;
import br.com.etec.model.dao.ClienteDAO;
import br.com.etec.model.vo.Cliente;
import br.com.etec.view.TelaPrp;
public class App {
	public static void main(String[] args) throws SQLException {
		TelaPrp formCliente = new TelaPrp();
		new Clientecontrol(formCliente);
		
		Cliente c1 = new Cliente();
		ClienteDAO clidao = new ClienteDAO();
		clidao.adicionar(c1);
	}

}
