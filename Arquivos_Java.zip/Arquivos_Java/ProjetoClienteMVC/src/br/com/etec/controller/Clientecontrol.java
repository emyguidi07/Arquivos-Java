package br.com.etec.controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.*;

import br.com.etec.model.dao.ClienteDAO;
import br.com.etec.model.vo.Cliente;
import br.com.etec.view.TelaPrp;

public class Clientecontrol implements ActionListener{
	TelaPrp formCliente;
	Cliente c1;
	ClienteDAO clidao = new ClienteDAO();
	
	public Clientecontrol(TelaPrp formCliente) {
		this.formCliente = formCliente;
		this.formCliente.getVerificar().addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.formCliente.getVerificar()) {
		c1 = new Cliente();
		c1.setNome(formCliente.getNome1().getText()); 
		c1.setCPF((formCliente.getCPF1().getText()));
		c1.setRG(Integer.parseInt(formCliente.getRG1().getText()));
		c1.setTelefone(Integer.parseInt(formCliente.getTel1().getText()));
		c1.setCidade(formCliente.getCidade1().getText());
		JOptionPane.showMessageDialog(null, "Cadastro do cliente:  \n" + " Nome do cliente: " + c1.getNome() + "\n CPF:"+ c1.getCPF() + "\n RG:" + c1.getRG() + "\n Telefone:" + c1.getTelefone() + "\n Cidade:" + c1.getCidade());
		try {
			clidao.adicionar(c1);
		}
		catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		}
	}
}
