package br.com.etec.model.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.etec.model.vo.Cliente;

public class ClienteDAO {
	private Connection connection;

public ClienteDAO(){
	this.connection = new ConnectionFactory().getConnection();
}
public void adicionar(Cliente cliente) throws SQLException {
	try {
		String sql = "insert into tbcliente"
				+ "(nome, cidade, RG, CPF, telefone)" 
				+ "values (?, ?, ?, ? ,?)";
		
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setString(1, cliente.getNome());
		stmt.setString(2, cliente.getCidade());
		stmt.setInt(3, cliente.getRG());
		stmt.setString(4, cliente.getCPF());
		stmt.setInt(5, cliente.getTelefone());
		
		stmt.execute();
		stmt.close();
	}
	catch(SQLException e) {
		System.out.println("Erro" + e);
	}
	finally {
		connection.close();
	}
 }
}

