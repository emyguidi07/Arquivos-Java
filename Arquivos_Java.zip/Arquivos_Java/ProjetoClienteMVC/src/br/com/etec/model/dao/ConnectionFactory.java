package br.com.etec.model.dao;

import java.sql.*;

public class ConnectionFactory {
	
	public Connection getConnection() {
		try {
			return DriverManager.getConnection("jdbc:mysql://localhost/bdcliente", "root", "");
		}
		catch(SQLException e) {
			throw new RuntimeException();
		}
	}
}
