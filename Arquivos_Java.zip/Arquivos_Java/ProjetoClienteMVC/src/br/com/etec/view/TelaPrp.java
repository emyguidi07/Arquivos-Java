package br.com.etec.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import br.com.etec.model.vo.Cliente;

public class TelaPrp extends JFrame{
	JLabel Nome, RG, CPF, tel, cidade;
	JTextField Nome1, RG1, CPF1, tel1, cidade1;
	JButton Verificar;
	
	
// get dos campos para recuperar o controller 
 public JTextField getNome1(){
	 return Nome1;
 }
 public JTextField getRG1(){
	 return RG1;
 }
 public JTextField getCPF1(){
	 return CPF1;
 }
 public JTextField getTel1(){
	 return tel1;
 }
 public JTextField getCidade1(){
	 return cidade1;
 }
 public JButton getVerificar(){
	 return Verificar;
 }
	
	public TelaPrp() {
		this.setTitle("Cliente - Cadastro");
	    this.setSize(500,400);  
	    this.setResizable(false);
	    this.setLocationRelativeTo(null);
	    this.getContentPane().setBackground(Color.white);
	    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	    this.setLayout(null);
	    
	    Container c = getContentPane();
	    
	    Nome = new JLabel("Nome:");
		Nome.setBounds(45,40,50,20);
		add(Nome);
		Nome1 = new JTextField();
		Nome1.setBounds(115, 40, 150, 20);
		c.add(Nome1);
		
		RG = new JLabel("RG:");
		RG.setBounds(45, 70, 50, 20);
		add(RG);
		RG1 = new JTextField();
		RG1.setBounds(115, 70, 150, 20);
		c.add(RG1);
		
		CPF= new JLabel("CPF:");
		CPF.setBounds(45, 100, 50, 20);
		add(CPF);
		CPF1 = new JTextField();
		CPF1.setBounds(115, 100, 150, 20);
		c.add(CPF1);
		
		tel= new JLabel("Telefone:");
		tel.setBounds(45, 130, 70, 20);
		add(tel);
		tel1 = new JTextField();
		tel1.setBounds(115, 130, 150, 20);
		c.add(tel1);
		
		cidade= new JLabel("Cidade:");
		cidade.setBounds(45, 160, 50, 20);
		add(cidade);
		cidade1 = new JTextField();
		cidade1.setBounds(115, 160, 150, 20);
		c.add(cidade1);
		
		
		Verificar= new JButton();
		Verificar.setBounds(50,250, 180, 30);
		Verificar.setBackground(Color.BLUE);
		Verificar.setForeground(Color.white);
		Verificar.setText("Visualizar dados");
			c.add(Verificar);
		
				
			setVisible(true);

	}
}
