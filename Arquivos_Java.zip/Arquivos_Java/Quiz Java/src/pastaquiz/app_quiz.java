package pastaquiz;

public class app_quiz {

	public static void main(String[] args) {
		new quiz();
	}

}
