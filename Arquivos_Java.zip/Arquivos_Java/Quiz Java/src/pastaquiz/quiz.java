package pastaquiz;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.*;
public class quiz extends JFrame{
	int soma=1;
	JLabel Pergunta1;
	JLabel Pergunta2;
	JLabel Pergunta3;
	JLabel Pergunta4;
	JLabel Pergunta5;
	JButton Resposta;
	ButtonGroup bgr;
	JRadioButton op1,op2,op3,op4, op5, op6, op7, op8,op9, op10, op11, op12, op13, op14, op15, op16, op17, op18, op19, op20;
	
	public quiz(){
		this.setSize(1300,900);
		this.setTitle("Quiz de DS");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(true);
		
		
		Container c = getContentPane();
		c.setLayout(null);
		 
		//pergunta1
		Pergunta1 = new JLabel();
		Pergunta1.setText("1 - Qual � a melhor forma de resolver um exerc�cio de tabuada?");
		Pergunta1.setBounds(30, 30, 600, 50);
		Pergunta1.setForeground(Color.BLUE);
		c.add(Pergunta1);
		
		bgr = new ButtonGroup();
		op1= new JRadioButton();
		op1.setText("Encadeamento de condi��es");
		op1.setBounds(30, 60, 600, 50);
		bgr.add(op1);
		c.add(op1);
		
		bgr = new ButtonGroup();
		op2= new JRadioButton();
		op2.setText("La�os de repeti��o");
		op2.setBounds(30, 90, 600, 50);
		bgr.add(op2);
		c.add(op2);
		
		bgr = new ButtonGroup();
		op3= new JRadioButton();
		op3.setText("Heran�a");
		op3.setBounds(30, 120, 600, 50);
		bgr.add(op3);
		c.add(op3);
		
		bgr = new ButtonGroup();
		op4= new JRadioButton();
		op4.setText("Encapsulamento");
		op4.setBounds(30, 150, 600, 50);
		bgr.add(op4);
		c.add(op4);
		
		//pergunta2
		Pergunta2 = new JLabel();
		Pergunta2.setText("2 - Como podemos organizar uma agenda telef�nica no Java?");
		Pergunta2.setBounds(30, 190, 600, 50);
		Pergunta2.setForeground(Color.BLUE);
		c.add(Pergunta2);
		
		bgr = new ButtonGroup();
		op5= new JRadioButton();
		op5.setText("Heran�a");
		op5.setBounds(30, 220, 600, 50);
		bgr.add(op5);
		c.add(op5);
		
		bgr = new ButtonGroup();
		op6= new JRadioButton();
		op6.setText("Polimorfismo");
		op6.setBounds(30, 250, 600, 50);
		bgr.add(op6);
		c.add(op6);
		
		bgr = new ButtonGroup();
		op7= new JRadioButton();
		op7.setText("Construtores");
		op7.setBounds(30, 280, 600, 50);
		bgr.add(op7);
		c.add(op7);
		
		bgr = new ButtonGroup();
		op8= new JRadioButton();
		op8.setText("Encapsulamento");
		op8.setBounds(30, 310, 600, 50);
		bgr.add(op8);
		c.add(op8);

		
		//pergunta3
		Pergunta4 = new JLabel();
		Pergunta4.setText("3 -O que s�o objetos?");
		Pergunta4.setBounds(30, 360, 600, 50);
		Pergunta4.setForeground(Color.BLUE);
		c.add(Pergunta4);
		
		bgr = new ButtonGroup();
		op9= new JRadioButton();
		op9.setText("S�o vari�veis");
		op9.setBounds(30, 390, 600, 50);
		bgr.add(op9);
		c.add(op9);
		
		bgr = new ButtonGroup();
		op10= new JRadioButton();
		op10.setText("S�o inst�ncias de classes");
		op10.setBounds(30, 420, 600, 50);
		bgr.add(op10);
		c.add(op10);
		
		bgr = new ButtonGroup();
		op11= new JRadioButton();
		op11.setText("S�o c�digos sobrescritos");
		op11.setBounds(30, 450, 600, 50);
		bgr.add(op11);
		c.add(op11);
		
		bgr = new ButtonGroup();
		op12= new JRadioButton();
		op12.setText("S�o m�todos abstratos");
		op12.setBounds(30, 480, 600, 50);
		bgr.add(op12);
		c.add(op12);
		

		//pergunta4
		Pergunta4 = new JLabel();
		Pergunta4.setText("4 -Assinale a alternativa correta dos benef�cios de POO em Java.");
		Pergunta4.setBounds(800, 30, 600, 50);
		Pergunta4.setForeground(Color.BLUE);
		c.add(Pergunta4);
		
		bgr = new ButtonGroup();
		op13= new JRadioButton();
		op13.setText("Diminuem o ciclo de vida dos projetos");
		op13.setBounds(800, 60, 600, 50);
		bgr.add(op13);
		c.add(op13);
		
		bgr = new ButtonGroup();
		op14= new JRadioButton();
		op14.setText("Dificultam a comunica��o entre desenvolvedores");
		op14.setBounds(800, 90, 600, 50);
		bgr.add(op14);
		c.add(op14);
		
		bgr = new ButtonGroup();
		op15= new JRadioButton();
		op15.setText("Encapsulam a l�gica");
		op15.setBounds(800, 120, 600, 50);
		bgr.add(op15);
		c.add(op15);
		
		bgr = new ButtonGroup();
		op16= new JRadioButton();
		op16.setText("N�o permitem flexibiliza��o do c�digo");
		op16.setBounds(800, 150, 600, 50);
		bgr.add(op16);
		c.add(op16);
		
		//pergunta5 
		Pergunta5 = new JLabel();
		Pergunta5.setText("5 - Qual o comando para gerar getters and setters?");
		Pergunta5.setBounds(800, 180, 600, 50);
		Pergunta5.setForeground(Color.BLUE);
		c.add(Pergunta5);
		
		bgr = new ButtonGroup();
		op17= new JRadioButton();
		op17.setText("Select all");
		op17.setBounds(800, 210, 600, 50);
		bgr.add(op17);
		c.add(op17);
		
		bgr = new ButtonGroup();
		op18= new JRadioButton();
		op18.setText("Source-Generate");
		op18.setBounds(800, 240, 600, 50);
		bgr.add(op18);
		c.add(op18);
		
		bgr = new ButtonGroup();
		op19= new JRadioButton();
		op19.setText("Source- Refactor");
		op19.setBounds(800, 270, 600, 50);
		bgr.add(op19);
		c.add(op19);
		
		bgr = new ButtonGroup();
		op20= new JRadioButton();
		op20.setText("Window-Navegation");
		op20.setBounds(800, 300, 600, 50);
		bgr.add(op20);
		c.add(op20);
		
		Resposta = new JButton();
		Resposta.setBounds(30, 580, 150, 25);
		Resposta.setText("Verificar resposta");
		Resposta.setForeground(Color.RED);
		Resposta.setBackground(Color.white);
		c.add(Resposta);
		Resposta.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(op2.isSelected() & op5.isSelected() & op10.isSelected() & op15.isSelected() & op18.isSelected()) {
					for (int cont=1; cont<4; cont++) {
						soma = soma + cont;	
						cont+=1;
					}
					if(soma==5) {
						JOptionPane.showMessageDialog(null, "Voc� acertou tudo!Parab�ns!");
					}
					else if(soma==4) {
						JOptionPane.showMessageDialog(null, "Voc� acertou apenas 4 quest�es!");
					}
					else if(soma==3) {
						JOptionPane.showMessageDialog(null, "Voc� acertou apenas 3 quest�es!");
					}
					else if(soma==2) {
						JOptionPane.showMessageDialog(null, "Voc� acertou apenas 2 quest�es!");
					}
					else if(soma==1) {
						JOptionPane.showMessageDialog(null, "Voc� acertou apenas 1 quest�o!");
					}
					else {
						JOptionPane.showMessageDialog(null, "Voc� n�o acertou nenhuma quest�o!Tente melhorar em DS!");
					}
				}
			}
		});
		
		this.setVisible(true);
	}
}
