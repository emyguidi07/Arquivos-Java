package ExemploFormul�rio;
public class App {
	public static void main(String[] args) {
		new FrmPrincipal();
	}
}
