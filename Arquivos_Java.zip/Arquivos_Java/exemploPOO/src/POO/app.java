package POO;
public class app {

	public static void main(String[] args) {
			Produto produto1 = new Produto();
			produto1.lerDadosProduto();
			produto1.exibirDadosProduto();

	}

}
