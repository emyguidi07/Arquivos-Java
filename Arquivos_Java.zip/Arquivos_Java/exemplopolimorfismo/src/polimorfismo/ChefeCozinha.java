package polimorfismo;

public class ChefeCozinha extends Cozinheiro{
	private String formacao;
	public String getFormacao() {
		return formacao;
	}
	public void setFormacao(String formacao) {
		this.formacao = formacao;
	}
	public String tipodePrato() {
		return prato = "Prato premium: sushis, salm�o flambado e carnes assadas";
	}
}
