package exerciciosiniciais;

import java.util.Scanner;

public class condicional1 {

	public static void main(String[] args) {
		// media 4 notas
		double nota1;
		double nota2;
		double nota3;
		double nota4;
		double media;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite a primeira nota: ");
		nota1 = sc.nextDouble();
		
		System.out.println("Digite a segunda nota: ");
		nota2 = sc.nextDouble();
		
		System.out.println("Digite a terceira nota: ");
		nota3 = sc.nextDouble();
		
		System.out.println("Digite a quarta nota: ");
		nota4 = sc.nextDouble();
		
		media = (nota1+nota2+nota3+nota4)/4;
		
		if(media>=7) {
			System.out.println("Aluno aprovado com m�dia " + media);
		}
		else {
			System.out.println("Aluno reprovado com m�dia " + media);
		}
	}

}
