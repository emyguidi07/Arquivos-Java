package exerciciosiniciais;

import java.util.Scanner;

public class condicional2 {

	public static void main(String[] args) {
		// cardapio
		int qtd;
		double preco;
		int indice;
		System.out.println("Card�pio do dia");
		System.out.println("1 ----------- Cachorro quente ------------ R$4.00");
		System.out.println("2 ----------- X-Salada ------------------- R$4.50");
		System.out.println("3 ----------- X_Bacon -------------------- R$5.00");
		System.out.println("4 ----------- Torrada simples ------------ R$2.00");
		System.out.println("5 ----------- Refrigerante --------------- R$1.50");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Escolha uma op��o: ");
		indice = sc.nextInt();
		System.out.println("Quantidade(s) do produto: ");
		qtd = sc.nextInt();
		
		if (indice==1) {
			preco=qtd*4;
			System.out.println("Total a pagar: R$"+preco);
		}
		else if(indice==2) {
			preco=qtd*4.50;
			System.out.println("Total a pagar: R$"+preco);
		}
		else if(indice==3) {
			preco=qtd*5;
			System.out.println("Total a pagar: R$"+preco);
		}
		else if(indice==4) {
			preco=qtd*2;
			System.out.println("Total a pagar: R$"+preco);
		}
		else if(indice==5) {
			preco=qtd*1.50;
			System.out.println("Total a pagar: R$"+preco);
		}
		else {
			System.out.println("N�mero inv�lido no card�pio");
		}
	}

}
