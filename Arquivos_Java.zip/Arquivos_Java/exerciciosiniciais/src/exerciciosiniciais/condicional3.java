package exerciciosiniciais;

import java.util.Scanner;

public class condicional3 {

	public static void main(String[] args) {
		// 3 valores
		int num1;
		int num2;
		int num3;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Escreva o primeiro n�mero: ");
		num1 = sc.nextInt();
		
		System.out.println("Escreva o segundo n�mero: ");
		num2 = sc.nextInt();
		
		System.out.println("Escreva o terceiro n�mero: ");
		num3 = sc.nextInt();
		
		if(num1 > num2 && num1 > num3) {
			System.out.println(num1 + " � o maior n�mero");
		}
		else if(num2 > num1 && num2 > num3) {
			System.out.println(num2 + " � o maior n�mero");
		}
		else {
			System.out.println(num3 + " � o maior n�mero");
		}
	}

}
