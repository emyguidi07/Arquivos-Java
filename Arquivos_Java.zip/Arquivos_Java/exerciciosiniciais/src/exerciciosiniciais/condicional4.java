package exerciciosiniciais;

import java.util.Scanner;

public class condicional4 {

	public static void main(String[] args) {
		// senha
		int senha;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Escreva uma senha: ");
		senha = sc.nextInt();
		
		if (senha==1234) {
			System.out.println("ACESSO PERMITIDO");
		}
		else {
			System.out.println("ACESSO NEGADO");
		}
	}

}
