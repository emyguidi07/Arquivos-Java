package exerciciosiniciais;

public class exemplotipos {
 
	public static void main(String[] args) {
		//exemplo booleano
		
		boolean Verdade = true;
		System.out.println(Verdade);
		
		//exemplo char
		char sexo = 'F';
		System.out.println(sexo);
		
		//exemplo int 
		int idade = 38;
		System.out.println(idade);
		
		//exemplo double 
		double salario = 2300.90;
		System.out.println(salario);
		
		//exemplo string
		String nome = "Emily";
		System.out.println(nome);
	}

}
