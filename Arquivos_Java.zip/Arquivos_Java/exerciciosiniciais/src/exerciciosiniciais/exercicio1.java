package exerciciosiniciais;

import java.util.Scanner;

public class exercicio1 {
	public static void main(String[] args) {
		// area 
		double num =3.14159;
        double raio;
        double area;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite quanto vale o raio:");
        raio = sc.nextDouble();
        
        area = num*(raio*raio);
        
        System.out.println("A =  " + area);
	}

}
