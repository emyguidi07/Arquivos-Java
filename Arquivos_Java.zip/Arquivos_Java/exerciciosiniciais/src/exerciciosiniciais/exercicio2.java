package exerciciosiniciais;

import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		// c�lculo sal�rio
		
		int htrabalho;
		int num;
		double valor;
		double salario;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite seu n�mero empresarial:");
        num = sc.nextInt();
        System.out.println("Digite suas horas trabalhadas:");
        htrabalho = sc.nextInt();
        System.out.println("Digite o valor da sua hora:");
        valor = sc.nextDouble();
        
        salario = valor*htrabalho;
        
        System.out.println("N�mero do funcion�rio:" + num);
        System.out.println("Sal�rio do funcion�rio:" + salario);
        
	}

}
