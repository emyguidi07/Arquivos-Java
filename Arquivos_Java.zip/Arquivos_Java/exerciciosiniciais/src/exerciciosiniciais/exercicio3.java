package exerciciosiniciais;

import java.util.Scanner;

public class exercicio3 {

	public static void main(String[] args) {
		// c�lculo de m�dia alunos
		
		double notaB;
		double notaA;
		double peso1;
		double peso2;
		double media;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite sua nota A: ");
		notaA = sc.nextDouble();
		
		System.out.println("Digite sua nota B: ");
		notaB = sc.nextDouble();
		
		peso1= notaA*3.5;
		peso2= notaB*7.5;
		media = (peso1+peso2)/11;
	    System.out.println("M�dia do aluno: " + media);
	}

}
