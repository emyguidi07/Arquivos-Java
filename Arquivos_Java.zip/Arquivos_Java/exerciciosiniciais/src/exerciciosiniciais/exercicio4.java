package exerciciosiniciais;

import java.util.Scanner;

public class exercicio4 {

	public static void main(String[] args) {
		// media numeros
		double num1;
		double num2;
		double num3;
		double peso1;
		double peso2;
		double peso3;
		double media;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite o primeiro n�mero: ");
		num1 = sc.nextDouble();
		
		System.out.println("Digite o segundo n�mero: ");
		num2 = sc.nextDouble();
		
		System.out.println("Digite o terceiro n�mero: ");
		num3 = sc.nextDouble();
		
		peso1= num1*2;
		peso2= num2*3;
		peso3= num3*5;
		media = (peso1+peso2+peso3)/10;
	    System.out.println("M�dia dos n�meros: " + media);

	}

}
