package exerciciosiniciais;

import java.util.Scanner;

public class exercicio5 {

	public static void main(String[] args) {
		// salario ajuste
		
		double sal;
		double aju;
		double rea;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite o seu sal�rio");
		sal= sc.nextDouble();
		
		System.out.println("Digite a % do ajuste de s�lario:");
		aju= sc.nextDouble();
		
		rea= sal*(1+(aju/100));
		
		System.out.println("Com o ajuste de " + aju+ "%.O sal�rio reajustado � de R$" + rea);
	}

}
