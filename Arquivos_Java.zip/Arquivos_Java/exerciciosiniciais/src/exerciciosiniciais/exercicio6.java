package exerciciosiniciais;

import java.util.Scanner;

public class exercicio6 {

	public static void main(String[] args) {
		// custos carro zero
		
		double cf;
		double imp;
		double dis;
		double ct;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite o custo de f�brica do carro: ");
		cf = sc.nextDouble();
		
		imp=0.45*cf;
		dis=0.28*cf;
		ct= cf+imp+dis;
		System.out.println("O custo total do carro ser� R$" + ct);
	}

}
