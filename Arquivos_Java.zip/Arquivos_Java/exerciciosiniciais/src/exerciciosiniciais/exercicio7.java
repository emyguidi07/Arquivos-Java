package exerciciosiniciais;

import java.util.Scanner;

public class exercicio7 {

	public static void main(String[] args) {
		// calculo hora
		int hora;
		int seg;
		int min;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite a quantidade de segundos : ");
		seg = sc.nextInt();
		
		hora = seg/3600;
		seg %= 3600;
		min = seg/60;
		seg %= 60;
		
		System.out.println("Isto corresponde a "+ hora + " horas " + min + " minutos e " + seg + " segundos");
	}

}
