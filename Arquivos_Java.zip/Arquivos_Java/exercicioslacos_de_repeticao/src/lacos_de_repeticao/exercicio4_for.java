package lacos_de_repeticao;

public class exercicio4_for {

	public static void main(String[] args) {
		// exibi��o n�meros 1 a 100
		
        for(int i = 1; i<= 200; i++) {
        	System.out.print(i + " ");	
        }

	}

}
