package matrizes;
import java.util.Scanner;

public class exercicio1_matriz {

	public static void main(String[] args) {
		int [][] matriz = new int [3][3];
		Scanner sc = new Scanner(System.in);
		int soma = 0;
		
		for(int i=0;i<=2;i++) {
			for(int j =0; j<=2; j++) {
			System.out.println("Digite um n�mero para a matriz: ");
			matriz[i][j]=sc.nextInt();
			}
		}
		for(int i=0;i<=2;i++) {
			for(int j =0; j<=2; j++) {
			soma += matriz[i][j];
			}
		}
		System.out.println("A soma dos n�meros da matriz � " + (soma));
		}
	}


