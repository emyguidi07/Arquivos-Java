package vetores;

import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {
		String[]pessoa = new String [4] ;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Seu nome: ");
		pessoa[0] = sc.next();
		System.out.println("Seu e-mail: ");
		pessoa[1] = sc.next();
		System.out.println("Assunto da mensagem: ");
		pessoa[2] = sc.next();
		System.out.println("Mensagem: ");
		pessoa[3] = sc.next();
		
		for(int i =0;i<=3;i++ ) {
			System.out.println(pessoa[i] + '\n');
		}
	}

}
