package vetores;

import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		double []nota = new double [4];
		double soma =0;
		Scanner sc = new Scanner(System.in);
		for(int i =0;i<=3;i++ ) {
			System.out.println("Digite uma nota: ");
			nota[i]=sc.nextDouble();
			soma += nota[i];
		}
		System.out.println("M�dia das notas: " + soma/4);
	}

}
