package vetores;


import java.util.Scanner;

public class exercicio3 {

	public static void main(String[] args) {
		// o mesmo que o exerc�cio 6
		int cont = 1;
	     int[] num = new int[10];

	     Scanner sc = new Scanner(System.in);
	    for (int i = 0; i < num.length; i++){  
	        System.out.print("Digite "+cont+"� n�mero: ");
	        num[i] = sc.nextInt();
	        cont++;
	        }

	    for (int i = 1; i < num.length; i++) {
	        for (int j = 0; j < i; j++) {
	            if (num[i] > num[j]) {
	                int a = num[i];
	                num[i] = num[j];
	                num[j] = a;
	            }
	        }
	    }
	    System.out.println("Ordem decrescente:");
	    for (int a : num) {
	        System.out.print(a + " - ");
	        }
		
	    
	}

}
