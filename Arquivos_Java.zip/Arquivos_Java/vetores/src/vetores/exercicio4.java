package vetores;

import java.util.Scanner;

public class exercicio4 {

	public static void main(String[] args) {
		int []num = new int [5];
		int max = 0;
		Scanner sc = new Scanner(System.in);
		
		for(int i=0;i<=4;i++) {
			System.out.println("Digite um n�mero: ");
			num[i]=sc.nextInt();
			if (num[i] > max){
	        	 max = num[i];
			}
		}
		System.out.println("Maior n�mero do vetor: " + max);
	}

}
