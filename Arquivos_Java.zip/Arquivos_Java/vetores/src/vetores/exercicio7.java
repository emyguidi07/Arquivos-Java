package vetores;

import java.util.Scanner;

public class exercicio7 {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Dados para vetor A");
        int []a = new int[5];
        for ( int i=0; i<5; i++ ) {
            System.out.println("Digite um n�mero: ");
            a[i]= sc.nextInt();
        }

        System.out.println("Dados para vetor B");
        int []b = new int[5];
        for ( int i=0; i<5; i++ ) {
            System.out.println("Digite um n�mero: ");
            b[i]= sc.nextInt();
        }
        
        //vetor c
        int []c = new int[10];
        for ( int i=0; i<5; i++ ) {
            c[i] = a[i];
        }
        for ( int i=5; i<10; i++ ) { 
            c[i] = b[i-5];
       	}
        
        //exibi��o de valores
        System.out.println(" \n O vetor A �: ");
        for(int i=0; i<a.length; i++) {
            System.out.print(a[i]+", ");
        }

        System.out.println(" \n O vetor B �: ");
        for(int x=0; x<b.length; x++) {
            System.out.print(b[x]+", ");
        }
        System.out.println(" \n O vetor C �: ");
        for ( int i=0; i<10; i++ ) {
            System.out.print(c[i] + ", ");
        }
	}

}
